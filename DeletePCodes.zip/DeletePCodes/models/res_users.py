from odoo import models, fields, _
from odoo.exceptions import UserError

class ResUsers(models.Model):
    _inherit = 'res.users'

    def archivar_productos_con_p(self):
        # Buscar plantillas de productos con 'P' en la referencia interna y que estén activas
        plantillas = self.env['product.template'].search([
            ('default_code', 'ilike', 'P'),
            ('active', '=', True)
        ])

        if not plantillas:
            raise UserError("No se encontraron productos activos con la referencia que contiene 'P'.")

        mensajes_bloqueo = []
        plantillas_inactivas = self.env['product.template']

        for plantilla in plantillas:
            # Verificar si alguna variante de la plantilla está en cotizaciones u órdenes en curso
            variantes_en_curso = self.env['sale.order.line'].search([
                ('product_id.product_tmpl_id', '=', plantilla.id),
                ('order_id.state', 'in', ['draft', 'sent'])
            ])
            if variantes_en_curso:
                ordenes_ids = variantes_en_curso.mapped('order_id.name')
                mensajes_bloqueo.append(
                    f"Producto '{plantilla.name}' está en uso en cotizaciones u órdenes: {', '.join(ordenes_ids)}"
                )
            else:
                plantillas_inactivas |= plantilla

        if plantillas_inactivas:
            plantillas_inactivas.write({'active': False})

        if mensajes_bloqueo:
            mensaje = (
                "Algunos productos no se archivaron porque están en cotizaciones u órdenes en curso:\n\n" +
                "\n".join(mensajes_bloqueo) +
                "\n\nDesvincúlalos primero para poder archivarlos."
            )
            raise UserError(mensaje)

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Productos archivados',
                'message': f'Se han archivado {len(plantillas_inactivas)} productos.',
                'type': 'success',
                'sticky': False,
            }
        }
