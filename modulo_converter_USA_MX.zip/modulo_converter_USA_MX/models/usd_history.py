from odoo import models, fields

class PurchaseProductUSDHistory(models.Model):
    _name = 'purchase.product.usd.history'
    _description = 'Historial de productos comprados en USD'

    purchase_order_id = fields.Many2one('purchase.order', string='Orden de compra', readonly=True)
    product_id = fields.Many2one('product.product', string='Producto', readonly=True)
    partner_id = fields.Many2one('res.partner', string='Proveedor', readonly=True)
    date_order = fields.Datetime(string='Fecha de orden', readonly=True)
    quantity = fields.Float(string='Cantidad', readonly=True)
    uom_id = fields.Many2one('uom.uom', string='Unidad de medida', readonly=True)
    price_unit_usd = fields.Float(string='Precio USD de compra', readonly=True)
    currency_id = fields.Many2one('res.currency', string='Moneda', readonly=True)
    user_id = fields.Many2one('res.users', string='Comprador', readonly=True)
