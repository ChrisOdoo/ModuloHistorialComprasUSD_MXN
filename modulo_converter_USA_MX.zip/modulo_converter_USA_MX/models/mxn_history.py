from odoo import models, fields

class PurchaseProductMXNHistory(models.Model):
    _name = 'purchase.product.mxn.history'
    _description = 'Historial de productos comprados en MXN'

    purchase_order_id = fields.Many2one('purchase.order', string='Orden de compra')
    product_id = fields.Many2one('product.product', string='Producto')
    partner_id = fields.Many2one('res.partner', string='Proveedor')
    date_order = fields.Datetime(string='Fecha de la orden')
    quantity = fields.Float(string='Cantidad')
    uom_id = fields.Many2one('uom.uom', string='Unidad de medida')
    price_unit_mxn = fields.Float(string='Precio Unitario en MXN')
    currency_id = fields.Many2one('res.currency', string='Moneda')
    user_id = fields.Many2one('res.users', string='Vendedor')
