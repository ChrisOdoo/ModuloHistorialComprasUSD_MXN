from odoo import models, fields

class ResUsers(models.Model):
    _inherit = 'res.users'

    valor_dollar = fields.Float(string="Valor del Dólar",default=22.0)
