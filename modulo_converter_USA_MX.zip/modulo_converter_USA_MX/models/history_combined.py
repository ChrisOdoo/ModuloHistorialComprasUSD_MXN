from odoo import _, models, fields, api, tools
from odoo.exceptions import UserError

class PurchaseProductHistoryCombined(models.Model):
    _name = 'purchase.product.history.combined'
    _description = 'Historial combinado de compras en USD y MXN'
    _auto = False  # Vista SQL

    purchase_order_id = fields.Many2one('purchase.order', string='Orden de Compra', readonly=True)
    partner_id = fields.Many2one('res.partner', string='Proveedor', readonly=True)
    quantity = fields.Float(string='Cantidad', readonly=True)
    uom_id = fields.Many2one('uom.uom', string='Unidad de Medida', readonly=True)
    user_id = fields.Many2one('res.users', string='Usuario', readonly=True)
    product_id = fields.Many2one('product.product', string='Producto', readonly=True)
    date_order = fields.Datetime(string='Fecha de Orden', readonly=True)
    price_unit = fields.Float(string='Precio Unitario', readonly=True)
    currency_id = fields.Many2one('res.currency', string='Moneda', readonly=True)

    convert_to_currency = fields.Char(
        string="Convertir a", compute="_compute_convert_to_currency", store=False
    )

    price_unit_converted = fields.Float(
        string="Precio Convertido", compute="_compute_price_unit_converted", store=False
    )

    @api.depends('price_unit', 'currency_id')
    def _compute_price_unit_converted(self):
        rate = self.env.user.valor_dollar or 1
        for rec in self:
            if rec.currency_id.name == 'USD':
                rec.price_unit_converted = rec.price_unit * rate
            elif rec.currency_id.name == 'MXN':
                rec.price_unit_converted = rec.price_unit
            else:
                rec.price_unit_converted = rec.price_unit

    @api.depends('currency_id')
    def _compute_convert_to_currency(self):
        for rec in self:
            if rec.currency_id.name == 'USD':
                rec.convert_to_currency = 'MXN'
            elif rec.currency_id.name == 'MXN':
                rec.convert_to_currency = 'MXN'
            else:
                rec.convert_to_currency = rec.currency_id.name

    def button_create_pl(self):
        raise UserError(_("¡crear LP!"))

    def init(self):
        tools.drop_view_if_exists(self._cr, self._table)
        self._cr.execute(f"""
            CREATE OR REPLACE VIEW {self._table} AS (
                SELECT 
                    id,
                    product_id,
                    date_order,
                    purchase_order_id,
                    partner_id,
                    quantity,
                    uom_id,
                    user_id,
                    price_unit,
                    currency_id
                FROM (
                    SELECT 
                        *,
                        ROW_NUMBER() OVER (
                            PARTITION BY product_id 
                            ORDER BY date_order DESC
                        ) AS rn
                    FROM (
                        SELECT 
                            id,
                            product_id,
                            date_order,
                            purchase_order_id,
                            partner_id,
                            quantity,
                            uom_id,
                            user_id,
                            price_unit_usd AS price_unit,
                            (SELECT id FROM res_currency WHERE name = 'USD') AS currency_id
                        FROM purchase_product_usd_history
                        
                        UNION ALL
                        
                        SELECT 
                            id,
                            product_id,
                            date_order,
                            purchase_order_id,
                            partner_id,
                            quantity,
                            uom_id,
                            user_id,
                            price_unit_mxn AS price_unit,
                            (SELECT id FROM res_currency WHERE name = 'MXN') AS currency_id
                        FROM purchase_product_mxn_history
                    ) AS all_purchases
                ) AS ranked
                WHERE rn = 1
            )
        """)
