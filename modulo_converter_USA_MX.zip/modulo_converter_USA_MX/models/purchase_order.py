from odoo import models, fields, api, _
from odoo.exceptions import UserError

class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    es_dollar = fields.Boolean(string='¿En Dollar USD?')
    valor_dollar = fields.Float(string='Valor del Dollar al momento')
    precio_original = fields.Float(string="Precio Original", readonly=True)


    def button_confirm(self):
        # Confirmar la orden (lógica original)
        res = super().button_confirm()
        
        # Obtener referencias a monedas
        usd_currency = self.env.ref('base.USD')
        mxn_currency = self.env.ref('base.MXN')  # <--- Nueva referencia

        # Guardar histórico en USD o MXN
        for order in self:
            for line in order.order_line:
                if order.es_dollar:
                    # Guardar en USD
                    self.env['purchase.product.usd.history'].create({
                        'purchase_order_id': order.id,
                        'product_id': line.product_id.id,
                        'partner_id': order.partner_id.id,
                        'date_order': order.date_order,
                        'quantity': line.product_qty,
                        'uom_id': line.product_uom.id,
                        'price_unit_usd': line.price_unit,
                        'currency_id': usd_currency.id, # <--- Moneda USD
                        'user_id': order.user_id.id,
                    })
                else:
                    # Guardar en MXN (Nueva lógica) <---
                    self.env['purchase.product.mxn.history'].create({
                        'purchase_order_id': order.id,
                        'product_id': line.product_id.id,
                        'partner_id': order.partner_id.id,
                        'date_order': order.date_order,
                        'quantity': line.product_qty,
                        'uom_id': line.product_uom.id,
                        'price_unit_mxn': line.price_unit,  
                        'currency_id': mxn_currency.id,  # <--- Moneda MXN
                        'user_id': order.user_id.id,
                    })
    
        return res

