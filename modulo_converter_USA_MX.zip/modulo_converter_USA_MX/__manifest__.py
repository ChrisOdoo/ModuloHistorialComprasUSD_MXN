# -*- coding: utf-8 -*-
{
    'name': "Check isDollar",
    'summary': "Extensión de compras con bandera para precios en USD",
    'description': """
     Módulo personalizado para Solo Fragancias:
     - Añade un campo que indica si el precio de compra es en dólares.
    """,
    'author': "Ing. Christian Padilla",
    'website': "",
    'category': 'Purchases',
    'version': '17.0.1.0',
    'depends': ['base', 'purchase'],
    'data': [
     'security/ir.model.access.csv',
     'views/usd_history_menu.xml',
     'views/usd_history_view.xml',
     'views/mxn_history_view.xml',
     'views/history_combined_view.xml',
     'views/purchase_order_views.xml',
     'views/res_users_dollar_views.xml',
    ],
    'license': 'LGPL-3',
    'installable': True,
    'application': False,
    'auto_install': False,
}
